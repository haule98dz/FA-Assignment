#include "LinkedList.h"

Node* LinkedList_head = NULL;

void LinkedList_InsertAfter(Node* previous_node, Node* new_node)
{
    new_node->next = previous_node->next;
    previous_node->next = new_node;
}

void LinkedList_PushToHead(Node* new_node)
{
    new_node->next = LinkedList_head;
    LinkedList_head = new_node;
}

bool LinkedList_DeleteAt(int position)
{
    bool flag_success = FALSE;
    Node* current_node;
    Node* previous_node;
    current_node = LinkedList_head;

    if (position == 0)
    {
        LinkedList_head = current_node->next;
        flag_success = TRUE;
    }
    else
    {
        int count = 1;

        while (current_node->next != NULL && flag_success == FALSE)
        {
            previous_node = current_node;
            current_node = previous_node->next;

            if (count == position)
            {
                *( current_node->address_of_data ) = 0xFF;
                previous_node->next = current_node->next;
                flag_success = TRUE;
            }
            else
            {
                count++;
            }
        }
    }

    return flag_success;
}

int LinkedList_Search(uint8_t searching_data)
{
    Node* current_node = LinkedList_head;
    uint8_t current_data;
    int count = 0;
    int retVal = -1;
    bool flag_stop = FALSE;

    while (current_node != NULL && flag_stop == FALSE)
    {
        current_data = *( current_node->address_of_data );

        if (current_data == searching_data)
        {
            retVal = count;
            flag_stop = TRUE;
        }
        else
        {
            current_node = current_node->next;
            count++;
        }
    }

    return retVal;
}

void LinkedList_Insert_MaintainOrder(Node* new_node)
{
    /* If list is empty, add node after the head */
    if (LinkedList_head == NULL)
    {
        LinkedList_PushToHead(new_node);
    }
    else
    {
        Node* current_node = LinkedList_head;
        uint8_t new_data = *( new_node->address_of_data );

        /* If there is 1 node */
        if (current_node->next == NULL)
        {
            /* Compare data, if new data is bigger then insert it after the node, else insert it after head */
            if (new_data > *(current_node->address_of_data))
            {
                LinkedList_InsertAfter(current_node, new_node);
            }
            else
            {
                LinkedList_PushToHead(new_node);
            }
        }
        else
        {
            Node* next_node = NULL;
            uint8_t next_data = 0;
            bool flag_stop = FALSE;

            while (current_node->next != NULL && flag_stop == FALSE)
            {
                next_node = current_node->next;
                next_data = *( next_node->address_of_data );

                if (new_data <= next_data)
                {
                    flag_stop = TRUE;
                }
                else
                {
                    current_node = next_node;
                }
            }

            if (current_node == LinkedList_head)
            {
                LinkedList_PushToHead(new_node);
            }
            else
            {
                LinkedList_InsertAfter(current_node, new_node);
            }
        }
    }
}

