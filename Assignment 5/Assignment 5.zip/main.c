/*******************************************************************************
* Includes
******************************************************************************/
#include <stdio.h>
#include <conio.h>
#include "LinkedList.h"

/*******************************************************************************
* Prototypes
******************************************************************************/
static void option1(void);
static void option2(void);
static void option3(void);

inline void pause(void)
{
    printf("\nPress any key to continue...");
    getch();
}

/*******************************************************************************
* Variables
******************************************************************************/
uint8_t assignment4[20] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

Node node[20];

/*******************************************************************************
* Codes
******************************************************************************/
int main(void)
{
    /*
    * Initiate array of nodes
    * Data in node i is the address of element i in array
    */
    int i;

    for (i = 0; i < 20; i++)
    {
        node[i].address_of_data = &assignment4[i];
    }

    /* Main process */

    bool flag_exit = FALSE;

    while (flag_exit == FALSE)
    {
        system("cls");
        printf("----ARRAY MANAGER USING LINKED LIST-----------------------\n");
        printf("  Enter 1 to set value for a specified element of the array.\n");
        printf("  Enter 2 to reset a specified element of the array.\n");
        printf("  Enter 3 to print all the values entered into the array.\n");
        printf("  Enter 4 to terminate the program.\n");
        printf("----------------------------------------------------------\n");

        fflush(stdin); /* Clear input buffer */
        int input;
        scanf("%d", &input);

        switch (input)
        {
            case 1: /* Set value for a specified element of the array */
            {
                option1();
                pause();
                break;
            }

            case 2: /* Reset a specified element of the array */
            {
                option2();
                pause();
                break;
            }

            case 3: /* Print all the values entered into the array. */
            {
                option3();
                pause();
                break;
            }

            case 4: /* Terminate the program. */
                flag_exit = TRUE;
                break;
        }
    }

    return 0;
}

static void option1(void)
{
    int position = 0;
    int value = 0;

    printf("Position (0 to 19): ");
    fflush(stdin);
    scanf("%d", &position);

    bool flag_error = FALSE;

    if (position < 0 || position > 19)
    {
        printf("Error: Out of range.");
        flag_error = TRUE;
    }
    else
    {
        if (assignment4[position] != 0xFF)
        {
            printf("Error: Position %d has already been assigned with a value.\n", position);
            flag_error = TRUE;
        }
    }

    if (flag_error == FALSE)
    {
        printf("Value (0 to 100): ");
        fflush(stdin);
        scanf("%d", &value);

        if (value < 0 || value > 100)
        {
            printf("Error: Out of range.\n");
            flag_error = TRUE;
        }
        else
        {
            int search_result;
            search_result = LinkedList_Search((uint8_t)value);

            if (search_result != -1)
            {
                printf("Error: Value already exists.\n");
                flag_error = TRUE;
            }
        }
    }

    if (flag_error == FALSE)
    {
        assignment4[position] = value;
        LinkedList_Insert_MaintainOrder(&node[position]);
        printf("Assign value %d to position %d successfully!\n", value, position);
    }
}

static void option2(void)
{

    int value = 0;
    bool flag_error = FALSE;

    printf("Value to delete (0 to 100): ");
    fflush(stdin);
    scanf("%d", &value);

    if (value < 0 || value > 100)
    {
        printf("Error: Out of range.\n");
        flag_error = TRUE;
    }
    else
    {
        int search_result;
        search_result = LinkedList_Search((uint8_t)value);

        if (search_result == -1)
        {
            printf("Error: Value does not exist in array.\n");
            flag_error = TRUE;
        }
        else
        {
            bool success = LinkedList_DeleteAt(search_result);

            if (success == TRUE)
            {
                printf("Deleted successfully.\n");
            }
            else
            {
                printf("Failed to delete.\n");
            }
        }
    }

}

static void option3(void)
{
    printf("Enter 1 to print all entered value in unsorted order.\n");
    printf("Enter 2 to print all entered value in sorted order.\n");

    int input = 0;

    do
    {
        fflush(stdin);
        scanf("%d", &input);

        if (input == 1)
        {
            int i;
            int data;
            putchar('\n');

            for (i = 0; i < 20; i++)
            {
                data = assignment4[i];

                if (data != 0xFF)
                {
                    printf("%d ", data);
                }
            }
        }
        else if (input == 2)
        {
            Node* current_node = LinkedList_head;
            int data;
            putchar('\n');

            while (current_node != NULL)
            {
                data = *( current_node->address_of_data );
                printf("%d ", data);
                current_node = current_node->next;
            }
        }
        else
        {
            printf("Invalid!\n Please retype: ");
            input = 0;
        }
    }
    while(input == 0);

    printf("\n\nDone printing.");
}

