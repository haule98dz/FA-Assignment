/*
  Assignment 1
*/

#include <stdio.h>
#include <stdlib.h>
#include "array_function.h"

#define MAX_SIZE 100

int array[MAX_SIZE];   //Mang luu giu lieu
int array_size = 0;   //So phan tu
