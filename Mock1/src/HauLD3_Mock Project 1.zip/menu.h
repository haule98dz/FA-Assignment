/**
 * @brief A program to browse FAT file system.
 */

#ifndef _READ_FILE_
#define _READ_FILE_

/*******************************************************************************
* API
******************************************************************************/

/**
 * @brief Call to app
 */
void menu(void);

#endif /* _READ_FILE_ */
