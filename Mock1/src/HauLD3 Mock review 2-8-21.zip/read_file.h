/**
 * @brief A program to browse FAT file system.
 *
 */

#ifndef _READ_FILE_
#define _READ_FILE_

/*******************************************************************************
* API
******************************************************************************/

/**
 * @brief Call to read-file-program
 */
void readfile_exec(void);

#endif /* _READ_FILE_ */
