/**
 * @brief Provides APIs to browse FAT disks. This module works with HAL.
 */

/*******************************************************************************
* Includes
******************************************************************************/

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "HAL.h"
#include "fatfs.h"

/*******************************************************************************
* Definitions
******************************************************************************/

#if (__GNU__)
#define FATFS_PACK __attribute__((packed))
#else
#define FATFS_PACK
#endif

#define FATFS_READ_UINT16(buff) (((uint16_t)((buff)[1]) << 8) | ((buff)[0]))

#define FATFS_READ_UINT32(buff) (((uint32_t)((buff)[3]) << 24) | ((uint32_t)((buff)[2]) << 16) | ((uint32_t)((buff)[1]) << 8) | ((buff)[0]))

typedef enum
{
    fatfs_type_fat12 = 0xFF8,
    fatfs_type_fat16 = 0xFFF8,
    fatfs_type_fat32 = 0x0FFFFFF8
} fatfs_type_t; /* Indicate FAT type, also EOF start cluster */

typedef struct
{
    uint8_t bytes_per_sector[2];       /* 0x00B */
    uint8_t sectors_per_cluster;       /* 0x00D */
    uint8_t count_reserved_sectors[2]; /* 0x00E */
    uint8_t number_of_fat_table;       /* 0x010 */
    uint8_t max_root_entries[2];       /* 0x011 */
    uint8_t total_sectors[2];          /* 0x013 */
    uint8_t media_descriptor;          /* 0x015 */
    uint8_t sectors_per_fat_table[2];  /* 0x016 */

    uint8_t physical_sectors_per_track[2]; /* 0x018 */
    uint8_t number_of_heads_for_disks[2];  /* 0x01A */
    uint8_t count_of_hidden_sectors[4];    /* 0x01C */
    uint8_t large_total_sectors[4];        /* 0x020 */
} FATFS_PACK fatfs_bios_parameter_block_struct_t;

typedef struct
{
    uint8_t physical_drive_number;      /* 0x024 */
    uint8_t reserved;                   /* 0x025 */
    uint8_t extended_boot_signature;    /* 0x026 */
    uint8_t volume_id[4];               /* 0x027 */
    uint8_t partition_volume_label[11]; /* 0x02B */
    uint8_t bitmask_system_type[8];     /* 0x036 */

    uint8_t specific_boot_code[447]; /* 0x03E */
} FATFS_PACK fatfs_extended_bpb_struct_t;

typedef struct
{
    uint8_t sectors_per_fat_table[4];         /* 0x024 */
    uint8_t drive_description[2];             /* 0x028 */
    uint8_t version[2];                       /* 0x02A */
    uint8_t root_dir_start_cluster[4];        /* 0x02C */
    uint8_t fs_info_start_sector[2];          /* 0x030 */
    uint8_t boot_sector_copy_start_sector[2]; /* 0x032 */
    uint8_t reserved[12];                     /* 0x034 */
    uint8_t physical_drive_number;            /* 0x040 */
    uint8_t for_various_purposes;             /* 0x041 */
    uint8_t extended_boot_signature;          /* 0x042 */
    uint8_t volume_id[4];                     /* 0x043 */
    uint8_t volume_label[11];                 /* 0x047 */
    uint8_t bitmask_system_type[8];           /* 0x052 */

    uint8_t specific_boot_code[419]; /* 0x05A */
} FATFS_PACK fatfs_fat32_extended_bpb_struct_t;

typedef struct
{
    uint8_t jump_instruction[3];              /* 0x000 */
    uint8_t oem_name[8];                      /* 0x003 */
    fatfs_bios_parameter_block_struct_t bpb;  /* 0x00B */
    fatfs_extended_bpb_struct_t extended_bpb; /* 0x024 */
    uint8_t physical_drive_number;            /* 0x1FD */
    uint8_t boot_sector_signature[2];         /* 0x1FE */
} FATFS_PACK fatfs_boot_sector_struct_t;

typedef struct
{
    fatfs_boot_sector_struct_t boot_sector;
    fatfs_type_t type;
    uint16_t sector_size;
    uint16_t cluster_size;
    uint32_t fat_index;  /* index sector of File Allocation Table region */
    uint32_t root_index; /* for FAT12/16 only, in case FAT32, this equal index sector of data region */
    uint32_t data_index; /* index sector of data region */
} fatfs_info_struct_t;

typedef enum
{
    entry_offset_short_file_name = 0x00,
    entry_offset_short_extension = 0x08,
    entry_offset_file_attributes = 0x0B,
    entry_offset_user_attributes = 0x0C,
    entry_offset_created_time_ms = 0x0D,
    entry_offset_created_time = 0x0E,
    entry_offset_created_date = 0x10,
    entry_offset_last_access_date = 0x12,
    entry_offset_access_right = 0x14,
    entry_offset_modified_time = 0x16,
    entry_offset_modified_date = 0x18,
    entry_offset_first_cluster = 0x1A,
    entry_offset_file_size = 0x1C
} fatfs_entry_offset_t;

typedef enum
{
    bitmask_read_only = 0x01,
    bitmask_hidden = 0x02,
    bitmask_system = 0x04,
    bitmask_volume_label = 0x08,
    bitmask_subdirectory = 0x10,
    bitmask_archive = 0x20,
    bitmask_device = 0x40,
    bitmask_reserve = 0x80
} fatfs_file_attribute_bitmask_t;

typedef enum
{
    entry_is_normal = 0,
    entry_is_long_file_name = 1,
    entry_is_deleted = 2,
    entry_is_hidden = 3,
    entry_is_the_end = 4
} fatfs_entry_status_t;

typedef enum
{
    cluster_type_data = 0,             /* 0x002 - 0xFEF    0x0002 - 0xFFEF    0x?0000002 - 0x?FFFFFEF */
    cluster_type_free = 1,             /* 0x000    0x0000    0x?0000000 */
    cluster_type_internal_purpose = 2, /* 0x001    0x0001    0x?0000001 */
    cluster_type_reserve = 3,          /* 0xFF0 - 0xFF5    0xFFF0 - 0xFFF5    0x?FFFFFF0 - 0x?FFFFFF5 */
    cluster_type_not_used = 4,         /* 0xFF6    0xFFF6    0x?FFFFFF6 */
    cluster_type_bad_sector = 5,       /* 0xFF7    0xFFF7    0x?FFFFFF7 */
    cluster_type_eof = 6               /* 0xFF8 - 0xFFF    0xFFF8 - 0xFFFF    0x?FFFFFF8 - 0x?FFFFFFF */
} fatfs_cluster_type_t;

/*******************************************************************************
* Prototypes
******************************************************************************/

/**
 * @brief Parse an entry, push to entry list if it's a normal entry
 *
 * @param buff Binary buffer
 * @return fatfs_entry_status_t Entry status
*/
static fatfs_entry_status_t fatfs_parse_entry(uint8_t *buff);

/**
 * @brief  Parse date and time data in Dictionary Entry into struct
 *
 * @param time_binary 16-bits time binary data
 * @param date_binary 16-bits date binary data
 * @param time Output time struct
 * @return true if parse successfully
 * @return false if parse failed
 */
static bool fatfs_parse_time(uint16_t time_binary, uint16_t date_binary, fatfs_time_struct_t *time);

/**
 * @brief add entry into entry list
 *
 * @param entry The entry to add into list
 */
void fatfs_update_entry_list(fatfs_entry_struct_t *entry);

/**
 * @brief Read and create entry list from data clusters
 *
 * @param first_cluster First cluster which store the subdirectory or root directory.
 *                      If first cluster equals 0, the system must be FAT12/16, then this function will read from root region.
 * @return fatfs_error_code_t Error code
 */
fatfs_error_code_t fatfs_create_entry_list(uint32_t first_cluster);

/*******************************************************************************
* Variables
******************************************************************************/

/* FAT file system information */
static fatfs_info_struct_t s_fatfs_info;

/* For FAT32 only: FAT32 Extended BIOS Parameter Block */
static fatfs_fat32_extended_bpb_struct_t *s_fatfs_fat32_extended_bpb_ptr;

/* Head pointer of entry list */
static fatfs_entry_struct_t *s_fatfs_entry_head_ptr = NULL;

/*******************************************************************************
* Static functions
******************************************************************************/

static bool fatfs_parse_time(uint16_t time_binary, uint16_t date_binary, fatfs_time_struct_t *time)
{
    /* Parse time */
    time->minute = (uint8_t)((time_binary >> 5) & 0x003F);
    time->hour = (uint8_t)(time_binary >> 11);

    /* Parse date */
    time->day = (uint8_t)(date_binary & 0x001F);
    time->month = (uint8_t)((date_binary >> 5) & 0x000F);
    time->year = (date_binary >> 9) + 1980;

    return true; /* Assuming no error */
}

void fatfs_update_entry_list(fatfs_entry_struct_t *entry)
{

    fatfs_entry_struct_t *current_entry = s_fatfs_entry_head_ptr;

    if (NULL == s_fatfs_entry_head_ptr)
    {
        entry->index = 1;
        s_fatfs_entry_head_ptr = entry;
    }
    else
    {
        while (NULL != current_entry->next)
        {
            current_entry = current_entry->next;
        }
        entry->index = current_entry->index + 1;
        current_entry->next = entry;
    }
}

static fatfs_entry_status_t fatfs_parse_entry(uint8_t *buff)
{

    fatfs_entry_status_t retVal = entry_is_normal;
    fatfs_entry_struct_t *entry;
    uint16_t time_binary;
    uint16_t date_binary;
    static int8_t long_file_name[256];
    static uint8_t long_file_name_len = 0;
    int8_t index = 0;

    if (0x0F == buff[entry_offset_file_attributes])
    {
        retVal = entry_is_long_file_name;
        if (0 != buff[0] | 0x40) /* if this entry is "the last logical LFN entry" */
        {
            long_file_name_len = 0;
        }
        for (index = 0; index < 10; index += 2, long_file_name_len++)
        {
            long_file_name[long_file_name_len] = buff[0x01 + index];
        }
        for (index = 0; index < 12; index += 2, long_file_name_len++)
        {
            long_file_name[long_file_name_len] = buff[0x0E + index];
        }
        for (index = 0; index < 4; index += 2, long_file_name_len++)
        {
            long_file_name[long_file_name_len] = buff[0x1C + index];
        }
        long_file_name_len += 26;
        /* Remove padding spaces */
        while (long_file_name[long_file_name_len - 1] == ' ')
        {
            long_file_name_len--;
        }
        long_file_name[long_file_name_len] = '\0';
    }
    else if (0 == buff[0])
    {
        retVal = entry_is_the_end;
    }
    else if (0xE5 == buff[0])
    {
        retVal = entry_is_deleted;
    }
    else if (0 != bitmask_hidden & buff[entry_offset_file_attributes])
    {
        retVal = entry_is_hidden;
    }
    else
    {
        retVal = entry_is_normal;
        entry = (fatfs_entry_struct_t *)malloc(sizeof(fatfs_entry_struct_t));

        /* Get file size */
        entry->file_size = FATFS_READ_UINT32(&buff[entry_offset_file_size]);

        /* Idicate that file is subdirectory or file */
        if ((0 != bitmask_subdirectory & buff[entry_offset_file_attributes]) || 0 == entry->file_size)
        {
            entry->is_subdir = true;
        }
        else
        {
            entry->is_subdir = false;
        }

        /* Get file extension */
        memcpy(&(entry->extension[0]), &buff[entry_offset_short_extension], 3);
        entry->extension[3] = '\0';

        /* Get file name */
        if (long_file_name_len > 0)
        {
            strcpy(entry->name, long_file_name);
            long_file_name_len = 0;
        }
        else
        {
            memcpy(&(entry->name[0]), &buff[entry_offset_short_file_name], 8);
            /* Ignore padding spaces in file name */
            for (index = 7; index >= 0 && buff[index] == ' '; index--)
            {
            }
            entry->name[index + 1] = '\0';
            if (!(entry->is_subdir))
            {
                /* Append extension to file name */
                entry->name[index + 1] = '.';
                strcpy(&(entry->name[index + 2]), &(entry->extension[0]));
            }
        }

        /* Get created date and time */
        time_binary = FATFS_READ_UINT16(&buff[entry_offset_created_time]);
        date_binary = FATFS_READ_UINT16(&buff[entry_offset_created_date]);
        fatfs_parse_time(time_binary, date_binary, &(entry->created_time));

        /* Get last modified date and time */
        time_binary = FATFS_READ_UINT16(&buff[entry_offset_modified_time]);
        date_binary = FATFS_READ_UINT16(&buff[entry_offset_modified_date]);
        fatfs_parse_time(time_binary, date_binary, &(entry->modified_time));
        /* Get first cluster */
        entry->first_cluster = FATFS_READ_UINT16(&buff[entry_offset_first_cluster]);

        entry->next = NULL;
        fatfs_update_entry_list(entry);
    }

    return retVal;
}

void fatfs_free_entry_list(void)
{

    fatfs_entry_struct_t *current_entry = s_fatfs_entry_head_ptr;
    fatfs_entry_struct_t *next_entry = NULL;

    while (NULL != current_entry)
    {
        next_entry = current_entry->next;
        free(current_entry);
        current_entry = next_entry;
    }
    s_fatfs_entry_head_ptr = NULL;
}

static uint32_t fatfs_get_next_cluster(uint32_t current_cluster)
{

    uint32_t retVal = 0;
    uint32_t index_sector_in_table = 0;
    uint32_t index_byte_in_sector = 0;
    uint8_t sector_to_read = 1;
    uint8_t *buff = NULL;
    int32_t bytes_read;

    switch (s_fatfs_info.type)
    {
    case fatfs_type_fat12:
        index_sector_in_table = (3 * current_cluster / 2) / s_fatfs_info.sector_size;
        index_byte_in_sector = (3 * current_cluster / 2) % s_fatfs_info.sector_size;
        /* If the cluster address lie in 2 consecutive sectors */
        if (1 == s_fatfs_info.sector_size - index_byte_in_sector)
        {
            sector_to_read = 2;
        }
        buff = (uint8_t *)malloc(sector_to_read * s_fatfs_info.sector_size);
        bytes_read = kmc_read_multi_sector(index_sector_in_table + s_fatfs_info.fat_index, sector_to_read, buff);

        if (0 == (3 * current_cluster) % 2)
        {
            retVal = buff[index_byte_in_sector + 1] & 0x0F; /* high half-byte */
            retVal <<= 8;
            retVal |= buff[index_byte_in_sector]; /* low full-byte */
        }
        else
        {
            retVal = buff[index_byte_in_sector + 1]; /* high full-byte */
            retVal <<= 4;
            retVal |= (buff[index_byte_in_sector] >> 4); /* low half byte */
        }

        free(buff);
        break;
    case fatfs_type_fat16:
        index_sector_in_table = 2 * current_cluster / s_fatfs_info.sector_size;
        index_byte_in_sector = (2 * current_cluster) % s_fatfs_info.sector_size;
        /* If the cluster address lie in 2 consecutive sectors */
        if (1 == s_fatfs_info.sector_size - index_byte_in_sector)
        {
            sector_to_read = 2;
        }
        buff = (uint8_t *)malloc(sector_to_read * s_fatfs_info.sector_size);
        bytes_read = kmc_read_multi_sector(index_sector_in_table + s_fatfs_info.fat_index, sector_to_read, buff);

        retVal = FATFS_READ_UINT16(&buff[index_byte_in_sector]);

        free(buff);
        break;
    case fatfs_type_fat32:
        index_sector_in_table = 4 * current_cluster / s_fatfs_info.sector_size;
        index_byte_in_sector = (4 * current_cluster) % s_fatfs_info.sector_size;
        /* If the cluster address lie in 2 consecutive sectors */
        if (3 >= s_fatfs_info.sector_size - index_byte_in_sector)
        {
            sector_to_read = 2;
        }
        buff = (uint8_t *)malloc(sector_to_read * s_fatfs_info.sector_size);
        bytes_read = kmc_read_multi_sector(index_sector_in_table + s_fatfs_info.fat_index, sector_to_read, buff);

        retVal = FATFS_READ_UINT32(&buff[index_byte_in_sector]);

        free(buff);
        break;
    }

    return retVal;
}

fatfs_cluster_type_t fatfs_check_cluster(uint32_t cluster_index)
{
    fatfs_cluster_type_t retVal = cluster_type_reserve;

    if (0 == cluster_index)
    {
        retVal = cluster_type_free;
    }
    else if (1 == cluster_index)
    {
        retVal = cluster_type_internal_purpose;
    }
    else if (cluster_index >= s_fatfs_info.type)
    {
        retVal = cluster_type_eof;
    }
    else
    {
        switch (s_fatfs_info.type)
        {
        case fatfs_type_fat12:
            if (cluster_index >= 0x002 && cluster_index <= 0xFEF)
            {
                retVal = cluster_type_data;
            }
            else if (cluster_index >= 0xFF0 && cluster_index <= 0xFF5)
            {
                retVal = cluster_type_reserve;
            }
            else if (0xFF6 == cluster_index)
            {
                retVal = cluster_type_not_used;
            }
            else
            {
                retVal = cluster_type_bad_sector;
            }
            break;
        case fatfs_type_fat16:
            if (cluster_index >= 0x0002 && cluster_index <= 0xFFEF)
            {
                retVal = cluster_type_data;
            }
            else if (cluster_index >= 0xFFF0 && cluster_index <= 0xFFF5)
            {
                retVal = cluster_type_reserve;
            }
            else if (0xFFF6 == cluster_index)
            {
                retVal = cluster_type_not_used;
            }
            else
            {
                retVal = cluster_type_bad_sector;
            }
            break;
        case fatfs_type_fat32:
            if (cluster_index >= 0x00000002 && cluster_index <= 0xFFFFFFEF)
            {
                retVal = cluster_type_data;
            }
            else if (cluster_index >= 0x0FFFFFF0 && cluster_index <= 0x0FFFFFF5)
            {
                retVal = cluster_type_reserve;
            }
            else if (0x0FFFFFF6 == cluster_index)
            {
                retVal = cluster_type_not_used;
            }
            else
            {
                retVal = cluster_type_bad_sector;
            }
            break;
        }
    }

    return retVal;
}

fatfs_error_code_t fatfs_create_entry_list(uint32_t first_cluster)
{

    fatfs_error_code_t retVal = error_code_success;
    uint8_t *buff = NULL;
    int32_t bytes_read = 0;
    uint8_t sector_to_read = 0;
    uint16_t count_sector;    /* Used for reading from FAT12/16 root region only */
    uint16_t sectors_in_root; /* Used for reading from FAT12/16 root region only */
    uint32_t cluster_index = first_cluster;
    uint16_t offset = 0;
    fatfs_entry_status_t entry_status = entry_is_normal;

    if (0 == first_cluster)
    {
        if (fatfs_type_fat32 != s_fatfs_info.type)
        {
            /* Reading from FAT12/16 root region */
            buff = (uint8_t *)malloc(s_fatfs_info.sector_size);
            sectors_in_root = s_fatfs_info.data_index - s_fatfs_info.root_index;
            for (count_sector = 0; entry_is_the_end != entry_status && count_sector < sectors_in_root; count_sector++)
            {
                bytes_read = kmc_read_sector(s_fatfs_info.root_index + count_sector, buff);
                for (offset = 0; entry_is_the_end != entry_status && offset < bytes_read; offset += 32)
                {
                    entry_status = fatfs_parse_entry(&buff[offset]);
                }
            }
            free(buff);
        }
        else
        {
            retVal = error_code_invalid_entry;
        }
    }
    else if (cluster_type_data != fatfs_check_cluster(first_cluster))
    {
        retVal == error_code_invalid_entry;
    }
    else
    {
        sector_to_read = s_fatfs_info.cluster_size;
        buff = (uint8_t *)malloc(sector_to_read * s_fatfs_info.sector_size);
        while (entry_is_the_end != entry_status)
        {
            bytes_read = kmc_read_multi_sector(s_fatfs_info.data_index + (cluster_index - 2) * s_fatfs_info.cluster_size, sector_to_read, buff);
            for (offset = 0; entry_is_the_end != entry_status && offset < bytes_read; offset += 32)
            {
                entry_status = fatfs_parse_entry(&buff[offset]);
            }
            cluster_index = fatfs_get_next_cluster(cluster_index);
            if (cluster_type_data != fatfs_check_cluster(cluster_index))
            {
                entry_status = entry_is_the_end;
            }
        }
        free(buff);
    }

    return retVal;
}

/*******************************************************************************
* Public functions
******************************************************************************/

fatfs_error_code_t fatfs_init(int8_t *file_path, fatfs_entry_struct_t **entry_list)
{

    fatfs_error_code_t retVal = error_code_success;
    int32_t bytes_read = 0;
    /* Number of sectors per FAT table read from Bios Parameter Block to identify FAT type */
    uint16_t bpb_sectors_per_fat_table;

    if (kmc_open(file_path))
    {
        /* Read boot sector */
        bytes_read = kmc_read_sector(0, (uint8_t *)&(s_fatfs_info.boot_sector));
        if (512 == bytes_read)
        {
            /* Identify FAT FS type */
            bpb_sectors_per_fat_table = FATFS_READ_UINT16(s_fatfs_info.boot_sector.bpb.sectors_per_fat_table);
            if (0 == bpb_sectors_per_fat_table) /* FAT32 sets this to 0 and uses the 32-bit value at offset 0x024 instead. */
            {
                s_fatfs_info.type = fatfs_type_fat32;
                s_fatfs_fat32_extended_bpb_ptr = (fatfs_fat32_extended_bpb_struct_t *)(&s_fatfs_info.boot_sector.extended_bpb);
                bpb_sectors_per_fat_table = FATFS_READ_UINT32(s_fatfs_fat32_extended_bpb_ptr->sectors_per_fat_table);
            }
            else if (12 >= bpb_sectors_per_fat_table) /* FAT12: 1 to 12 sectors per copy of FAT */
            {
                s_fatfs_info.type = fatfs_type_fat12;
            }
            else
            {
                s_fatfs_info.type = fatfs_type_fat16; /* FAT16: 16 to 256 sectors per copy of FAT */
            }
            /* Parse some parameters */
            s_fatfs_info.sector_size = FATFS_READ_UINT16(s_fatfs_info.boot_sector.bpb.bytes_per_sector);
            s_fatfs_info.cluster_size = s_fatfs_info.boot_sector.bpb.sectors_per_cluster;

            s_fatfs_info.fat_index = FATFS_READ_UINT16(s_fatfs_info.boot_sector.bpb.count_reserved_sectors);
            if (fatfs_type_fat32 == s_fatfs_info.type)
            {
                s_fatfs_info.data_index = s_fatfs_info.fat_index + bpb_sectors_per_fat_table * s_fatfs_info.boot_sector.bpb.number_of_fat_table;
            }
            else
            {
                s_fatfs_info.root_index = s_fatfs_info.fat_index + bpb_sectors_per_fat_table * s_fatfs_info.boot_sector.bpb.number_of_fat_table;
                s_fatfs_info.data_index = s_fatfs_info.root_index + (FATFS_READ_UINT16(s_fatfs_info.boot_sector.bpb.max_root_entries) * 32) / s_fatfs_info.sector_size;
            }

            /* Open root directory */
            if (fatfs_type_fat32 == s_fatfs_info.type)
            {
                retVal = fatfs_create_entry_list(FATFS_READ_UINT32(s_fatfs_fat32_extended_bpb_ptr->root_dir_start_cluster));
            }
            else
            {
                retVal = fatfs_create_entry_list(0);
            }
            *entry_list = s_fatfs_entry_head_ptr;
        }
        else
        {
            retVal = error_code_read_boot_failed;
        }
    }
    else
    {
        retVal = error_code_open_failed;
    }

    return retVal;
}

fatfs_error_code_t fatfs_open_dir(fatfs_entry_struct_t *entry, fatfs_entry_struct_t **entry_list)
{

    fatfs_error_code_t retVal = error_code_success;
    uint32_t index;

    fatfs_free_entry_list();
    retVal = fatfs_create_entry_list(entry->first_cluster);

    if (error_code_success == retVal)
    {
        *entry_list = s_fatfs_entry_head_ptr;
    }

    return retVal;
}

fatfs_error_code_t fatfs_open_file(fatfs_entry_struct_t *entry, uint8_t **file_buff_ptr, uint32_t *size)
{

    fatfs_error_code_t retVal = error_code_success;
    uint8_t *cluster_buff = NULL;
    uint32_t cluster_index = entry->first_cluster;
    int32_t bytes_read;
    uint32_t byte_index = 0;

    (*size) = 0;
    for (cluster_index = entry->first_cluster; cluster_type_data == fatfs_check_cluster(cluster_index); cluster_index = fatfs_get_next_cluster(cluster_index))
    {
        (*size) += s_fatfs_info.cluster_size * s_fatfs_info.sector_size;
    }
    if (0 == (*size))
    {
        retVal = error_code_invalid_entry;
    }
    else
    {
        *file_buff_ptr = (uint8_t *)malloc((*size));
        cluster_buff = (uint8_t *)malloc(s_fatfs_info.cluster_size * s_fatfs_info.sector_size);
        cluster_index = entry->first_cluster;
        do
        {
            bytes_read = kmc_read_multi_sector(s_fatfs_info.data_index + (cluster_index - 2) * s_fatfs_info.cluster_size, s_fatfs_info.cluster_size, cluster_buff);
            if (bytes_read == s_fatfs_info.cluster_size * s_fatfs_info.sector_size)
            {
                memcpy(&(*file_buff_ptr)[byte_index], &cluster_buff[0], bytes_read);
                byte_index += bytes_read;
            }
            else
            {
                retVal = error_code_read_cluster_failed;
            }
            cluster_index = fatfs_get_next_cluster(cluster_index);
            if (cluster_type_eof == fatfs_check_cluster(cluster_index))
            {
                break;
            }
        } while (error_code_success == retVal);
        free(cluster_buff);
    }
    return retVal;
}

fatfs_error_code_t fatfs_deinit(void)
{

    fatfs_error_code_t retVal = error_code_success;

    if (kmc_close())
    {
        fatfs_free_entry_list();
    }
    else
    {
        retVal = error_code_close_failed;
    }

    return retVal;
}
