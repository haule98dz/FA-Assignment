/**
 * @brief Provides APIs to browse FAT File System.
 */

#ifndef _FATFS_
#define _FATFS_

/*******************************************************************************
* Definitions
******************************************************************************/

typedef enum
{
    error_code_success = 0,
    error_code_open_failed = 1,
    error_code_read_boot_failed = 2,
    error_code_invalid_entry = 3,
    error_code_invalid_entry_index = 4,
    error_code_read_cluster_failed = 5,
    error_code_close_failed = 6
} fatfs_error_code_t;

typedef struct
{
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
} fatfs_time_struct_t;

typedef struct _entry
{
    fatfs_time_struct_t created_time;
    fatfs_time_struct_t modified_time;
    char name[255];
    char extension[4];
    uint32_t first_cluster;
    uint32_t file_size;
    bool is_subdir;

    uint16_t index;
    struct _entry *next;
} fatfs_entry_struct_t;

/*******************************************************************************
* API
******************************************************************************/

/**
 * @brief initiate FAT
 *
 * @param file_path File path
 * @return fatfs_error_code_t error code
 */
fatfs_error_code_t fatfs_init(int8_t *file_path, fatfs_entry_struct_t **entry_list);

/**
 * @brief Open a subdirectory
 *
 * @param entry Subdirectory entry
 * @param entry_list Output: Pointer to the header of entry list
 * @return fatfs_error_code_t Error code
 */
fatfs_error_code_t fatfs_open_dir(fatfs_entry_struct_t *entry, fatfs_entry_struct_t **entry_list);

/**
 * @brief Read a file
 *
 * @param entry File entry
 * @param file_buff_ptr Output: file data buffer
 * @param size Output: Size of file data buffer
 * @return fatfs_error_code_t Error code
 */
fatfs_error_code_t fatfs_open_file(fatfs_entry_struct_t *entry, uint8_t **file_buff_ptr, uint32_t *size);

/**
 * @brief Close file, free dynamic memory
 *
 * @return fatfs_error_code_t Error code
 */
fatfs_error_code_t fatfs_deinit(void);

#endif /* _FAT12_ */
